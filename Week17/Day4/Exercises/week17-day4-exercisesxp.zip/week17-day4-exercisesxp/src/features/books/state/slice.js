import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { books } from '../../../app/data';

const initialState = {
books: [],
};

export const fetchBooks = createAsyncThunk('books/fetchBooks', async () => {
    const response = await axios.get(books);
    return response.data;
});

export const booksSlice = createSlice({
    name: 'books',
    initialState,
    reducers: {
        selectBooks: (state) => {
            state.books = books;
        },
        selectBooksByGenre: (state, action) => {
            const selectedGenre = action.payload;
            state.books = books.filter(book => book.genre === selectedGenre);
        },
    },
    extraReducers(builder) {
        builder
        .addCase(fetchBooks.pending, (state) => {
            state.status = 'loading';
        })
        .addCase(fetchBooks.fulfilled, (state, action) => {
            state.status = 'success';
            state.books = action.payload;
        })
        .addCase(fetchBooks.rejected, (state) => {
            state.status = 'failed';
        });
    },
});

export const selectStatus = (state) => state.books.status;
export const sliceState = (state) => state.books;

export const { selectBooks, selectBooksByGenre } = booksSlice.actions;
export default booksSlice.reducer;