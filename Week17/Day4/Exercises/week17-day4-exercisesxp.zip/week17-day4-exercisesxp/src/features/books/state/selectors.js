import { createSelector } from '@reduxjs/toolkit';
import { sliceState } from './slice'; // Add this line

export const selectBooks = createSelector([sliceState], (state) => state.books) // Replace 'state' with 'sliceState'

export const selectStatus = createSelector([sliceState], (state) => state.status) // Replace 'state' with 'sliceState'