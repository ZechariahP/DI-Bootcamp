import { useState, useEffect } from 'react';
import { useBooksSelector } from './state/hooks';
import GenreSelectorDropdown from './GenreSelectorDropdown';
import { useFetchBooks } from './state/hooks';

const BookList = () => {
    const fetchedBooks = useBooksSelector();
    const callFetchBooks = useFetchBooks();
    const [selectedGenre, setSelectedGenre] = useState('');

    useEffect(() => {
        callFetchBooks();
    }, []);

    const handleGenreChange = (genre) => {
        setSelectedGenre(genre);
    };

    const filteredBooks = selectedGenre
        ? fetchedBooks.filter((book) => book.genre === selectedGenre)
        : [];

    const BookInventory = () => (
        <>
            <h2>Book Inventory</h2>
            <GenreSelectorDropdown onChange={handleGenreChange} />
            <ul>
                {filteredBooks.map((book) => (
                    <article key={book.id}>
                        <h3>{book.title}</h3> by {book.author} ({book.genre})
                    </article>
                ))}
            </ul>
        </>
    );

    return <BookInventory />;
};

export default BookList;
