import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { selectBooks, selectBooksByGenre } from '../features/books/state/slice';
import { books } from './data.js';

export const appReducer = combineReducers({
    books: selectBooks, selectBooksByGenre
});

const store = configureStore({
    reducer: appReducer,
});

export default store;