import {configureStore} from '@reduxjs/toolkit';

const tasksReducer = (state = {}, action) => {
  switch (action.type) {
    case 'tasks/addTask':
      const {day = '', task} = action.payload || { day: '', task: null } || { day: '', task: null };
      return {
        ...state,
        [day]: [...(state[day] || []), task],
      };
    case 'tasks/editTask':
      const {day: editDay, task: editedTask} = action.payload;
      return {
        ...state,
        [editDay]: state[editDay] ? state[editDay].map((task) =>
          task.id === editedTask.id ? editedTask : task
        ) : [],
      };
    case 'tasks/deleteTask':
      const {day: deleteDay, taskId} = action.payload;
      return {
        ...state,
        [deleteDay]: state[deleteDay].filter((task) => task.id !== taskId),
      };
    default:
      return state;
  }
}

export const store = configureStore({
  reducer: {
    tasks: tasksReducer,
  },
});
