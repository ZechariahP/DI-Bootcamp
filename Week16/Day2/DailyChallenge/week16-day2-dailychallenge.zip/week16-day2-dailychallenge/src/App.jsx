import React from 'react';
import { Provider } from 'react-redux';
import { connect } from 'react-redux';
import { DatePicker } from './components/DatePicker';
import { TaskDisplay } from './components/TaskDisplay';
import { addTask, editTask, deleteTask } from './actions';
import { store } from './store';
import { DeleteTask } from './components/DeleteTask';
import { AddTask } from './components/AddTask';
import { EditTask } from './components/EditTask';


const mapStateToProps = (state, ownProps) => ({
  tasks: state.tasks[ownProps.day] || [],
});

const mapDispatchToProps = (dispatch) => ({
  addTask: (day, task) => dispatch(addTask(day, task)),
  editTask: (day, task) => dispatch(editTask(day, task)),
  deleteTask: (day, taskId) => dispatch(deleteTask(day, taskId)),
});

const ConnectedDatePicker = connect(
  mapStateToProps,
  mapDispatchToProps
)(DatePicker);

const DisplayDate = ({ day }) => {
  return <h1>{day}</h1>;
}

const App = () => {
  return (
    <Provider store={store}>
      <div>
        <ConnectedDatePicker />
        <DisplayDate />
        <AddTask />
        <EditTask />
        <DeleteTask/>
        <TaskDisplay />
      </div>
    </Provider>
  );
}

export default App;
