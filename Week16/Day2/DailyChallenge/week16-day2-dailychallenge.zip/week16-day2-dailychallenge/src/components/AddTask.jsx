import React, {useState} from 'react';
import {useDispatch} from 'react-redux';
import {addTask} from '../actions';

export const AddTask = ({day}) => {
    const [taskName, setTaskName] = useState('');
    const dispatch = useDispatch();

    const handleTaskNameChange = (e) => {
        setTaskName(e.target.value);
    };

    const handleAddTask = () => {
        dispatch(addTask(day, {id: Date.now(), name: taskName, date: ''}));
        setTaskName('');
    };

    return (
        <div>
            <input type="text" value={taskName} onChange={handleTaskNameChange} />
            <button onClick={handleAddTask}>Add Task</button>
        </div>
    );
};