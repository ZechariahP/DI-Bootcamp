import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { editTask } from '../actions';

export const EditTask = ({ day, task }) => {
    const [taskName, setTaskName] = useState(task?.name || ''); // Add null check and default value
    const dispatch = useDispatch();

    const handleTaskNameChange = (e) => {
        setTaskName(e.target.value);
    };

    const handleEditTask = () => {
        dispatch(editTask(day, { ...task, name: taskName }));
    };

    return (
        <div>
            <input type="text" value={taskName} onChange={handleTaskNameChange} />
            <button onClick={handleEditTask}>Edit Task</button>
        </div>
    );
};





