import React from 'react';
import {useDispatch} from 'react-redux';
import {deleteTask} from '../actions';

export const DeleteTask = ({day, task}) => {
    const dispatch = useDispatch();

    const handleDeleteTask = () => {
        dispatch(deleteTask(day, task.id));
    };

    return (
        <div>
            <button onClick={handleDeleteTask}>Delete Task</button>
        </div>
    );
}

