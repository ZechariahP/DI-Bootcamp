import React from 'react';
import { useDispatch } from 'react-redux';
import { editTask } from '../actions';

export const DatePicker = ({ day, task }) => {
    const dispatch = useDispatch();

    const handleDateChange = (e) => {
        dispatch(editTask(day, { ...task, date: e.target.value }));
    };

    return (
        <input type="date" value={task?.date || ''} onChange={handleDateChange} />
    );
};