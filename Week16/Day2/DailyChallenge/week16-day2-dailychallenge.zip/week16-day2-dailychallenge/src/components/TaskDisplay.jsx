import React from 'react';
import { useDispatch } from 'react-redux';
import { editTask, deleteTask } from '../actions';

export const TaskDisplay = ({ day, tasks }) => {
    const dispatch = useDispatch();

    const handleTaskChange = (e, task) => {
        dispatch(editTask(day, { ...task, name: e.target.value }));
    };

    const handleDeleteTask = (taskId) => {
        dispatch(deleteTask(day, taskId));
    };

    return (
        <ul>
            {tasks && tasks.map((task) => (
                <li key={task.id}>
                    <input
                        type="text"
                        value={task.name}
                        onChange={(e) => handleTaskChange(e, task)}
                    />
                    <button onClick={() => handleDeleteTask(task.id)}>Delete</button>
                </li>
            ))}
        </ul>
    );
};

