import {createSlice} from '@reduxjs/toolkit';

export const tasksSlice = createSlice({
    addTask: (day, task) => ({
        type: 'tasks/addTask',
        payload: {day, task},
    }),
    
    editTask: (day, task) => ({
        type: 'tasks/editTask',
        payload: {day, task},
    }),
    
    deleteTask: (day, taskId) => ({
        type: 'tasks/deleteTask',
        payload: {day, taskId},
    }),
    name: 'tasks',
    initialState: {},
    reducers: {
        addTask(state, action) {
            const {day, task} = action.payload;
            state[day] = [...(state[day] || []), task];
        },
        editTask(state, action) {
            const {day: editDay, task: editedTask} = action.payload;
            state[editDay] = state[editDay].map((task) =>
            task.id === editedTask.id ? editedTask : task
            );
        },
        deleteTask(state, action) {
            const {day: deleteDay, taskId} = action.payload;
            state[deleteDay] = state[deleteDay].filter((task) => task.id !== taskId);
        },
    },
});

export const {addTask, editTask, deleteTask} = tasksSlice.actions;