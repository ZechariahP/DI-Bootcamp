import ShowInput from './ShowInput';

const Display = () => {
    return (
        <>
        <h2>This is the text:</h2>
        <ShowInput/>
        </>
    );
}

export default Display;