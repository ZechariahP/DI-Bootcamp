import { useContext } from 'react';
import { AppContext2 } from 'react';


const Input = () => {
    const { setText } = useContext(AppContext);
    return (
        <>
            <input onChange={(e)=> setText(e.target.value) } />
        </>
    );
}

export default Input;