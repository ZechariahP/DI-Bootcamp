import { useState, createContext } from 'react';
import './App.css';
import Display from './components/display/Display';
import Action from './components/actions/Action';

export const AppContext2 = createContext();

function App2() {
  const [text, setText] = useState('text is going to be changed');
   
  return (
    <>
      <h2>The createContext, useContext Hook</h2>
      <AppContext2.Provider value={{text, setText}}>
        <Display text={text}/>
        <Action setText={setText}/>
      </AppContext2.Provider>
    </>
  );
}

export default App2;